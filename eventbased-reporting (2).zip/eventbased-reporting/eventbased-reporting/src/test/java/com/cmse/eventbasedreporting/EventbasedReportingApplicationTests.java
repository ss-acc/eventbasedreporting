package com.cmse.eventbasedreporting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventbasedReportingApplicationTests {

	@Test
	void contextLoads() {
	}

}

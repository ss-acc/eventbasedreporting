package com.cmse.eventbasedreporting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventbasedReportingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventbasedReportingApplication.class, args);
	}

}

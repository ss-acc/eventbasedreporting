package com.cmse.eventbasedreporting.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.cmse.eventbasedreporting.model.Cards;

@Slf4j
@Service
@RequiredArgsConstructor
public class KafkaProducer {
	
	private  KafkaTemplate<String, Cards> kafkaTemplate;

    @Value("${topic.name}")
    private String topicName;

    public void send(Cards message) {
        this.kafkaTemplate.send(topicName, message);
     System.out.println(topicName);
        
    }

}

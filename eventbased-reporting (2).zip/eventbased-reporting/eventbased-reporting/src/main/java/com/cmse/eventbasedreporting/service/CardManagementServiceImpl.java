package com.cmse.eventbasedreporting.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cmse.eventbasedreporting.model.Cards;
import com.cmse.eventbasedreporting.repository.CardsRepository;

@Service
public class CardManagementServiceImpl implements CardManagementService {
	
	 @Autowired
	 CardsRepository cardRepo;
	 
	 	
	@Override
    public List<Cards> getCardDetails() {
        return cardRepo.findAll();
    }

}

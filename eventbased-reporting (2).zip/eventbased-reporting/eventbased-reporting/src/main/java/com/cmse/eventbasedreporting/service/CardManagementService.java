package com.cmse.eventbasedreporting.service;

import java.util.List;

import com.cmse.eventbasedreporting.model.Cards;

public interface CardManagementService {
	
	List<Cards> getCardDetails();

}

package com.cmse.eventbasedreporting.controller;

import java.io.IOException;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import jakarta.servlet.http.HttpServletResponse;

import com.cmse.eventbasedreporting.model.Cards;

import com.cmse.eventbasedreporting.repository.CardsRepository;
import org.slf4j.Logger;

import java.util.Optional;

import com.cmse.eventbasedreporting.utils.ReportsGenerator;

import org.springframework.beans.factory.annotation.Value;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api")
public class CardsController {

	private static final Logger logger = LoggerFactory.getLogger(CardsController.class);
	@Autowired
	private CardsRepository cardRepository;

	@Autowired
	KafkaTemplate<String, Cards> kafkaTemplate;

	@Value("${topic.name}")
	private String topicName;

	@GetMapping("/cards")
	public List<Cards> getAllCards() {
		return cardRepository.findAll();
	}

	@GetMapping("{cardno}")
	public ResponseEntity<Cards> getCardsById(@PathVariable long cardno) {

		Optional<Cards> cards = cardRepository.findById(cardno);

		return cards.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());

	}

	@PutMapping("{cardno}")
	public ResponseEntity<Cards> updateStatus(@PathVariable long cardno, @RequestBody String cardstatus) {
		Optional<Cards> optionalEntity = cardRepository.findById(cardno);
		if (optionalEntity.isPresent()) {
			Cards cards = optionalEntity.get();
			cards.setCardstatus(cardstatus);
			System.out.println("printing CardStatu:" + cardstatus);
			Cards updatedEntity = cardRepository.save(cards);
			logger.info(String.format("#### -> Producing message -> %s", updatedEntity));
			kafkaTemplate.send(topicName, updatedEntity);
			return ResponseEntity.ok(updatedEntity);
		} else {
			return ResponseEntity.notFound().build();

		}
	}

	@GetMapping("/export-to-excel")
	public void exportIntoExcelFile(@RequestParam("status") String cardstatus, HttpServletResponse response)
			throws IOException {
		response.setContentType("application/octet-stream");
	
		List<Cards> crddet = cardRepository.findByCardstatus(cardstatus);
		ReportsGenerator generator = new ReportsGenerator(crddet);
		generator.generateExcelFile(response);
	}

}

package com.cmse.eventbasedreporting.service;
import org.springframework.stereotype.Service;

import com.cmse.eventbasedreporting.controller.CardsController;
import com.cmse.eventbasedreporting.model.Cards;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;


@Service
public class KafkaConsumer {
	
	 private final Logger logger = LoggerFactory.getLogger(CardsController.class);
	
	 @KafkaListener(topics = "${topic.name}")
	    public void receive(List<Cards> consumerMessage) {
		 logger.info(String.format("#### -> Consumed message -> %s", consumerMessage));
		
	 }

}

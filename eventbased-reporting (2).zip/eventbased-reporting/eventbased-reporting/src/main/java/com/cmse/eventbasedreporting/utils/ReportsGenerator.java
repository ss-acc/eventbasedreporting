package com.cmse.eventbasedreporting.utils;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cmse.eventbasedreporting.model.Cards;

public class ReportsGenerator {

	private List<Cards> cardDetailsList;
	private XSSFWorkbook workbook;
	private XSSFSheet sheet;

	public ReportsGenerator(List<Cards> cardDetailsList) {
		this.cardDetailsList = cardDetailsList;
		workbook = new XSSFWorkbook();
	}

	private void writeHeader() {
		sheet = workbook.createSheet("Negative File Report");
		Row row = sheet.createRow(0);
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setFontHeight(16);
		style.setFont(font);
		createCell(row, 0, "CardNo", style);
		createCell(row, 1, "CardHolder Name", style);
		createCell(row, 2, "cardbalance", style);
		createCell(row, 3, "cardissueddate", style);
		createCell(row, 4, "cardexpirydate", style);
		createCell(row, 5, "cardstatus", style);
		createCell(row, 5, "bankid", style);

	}

	private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
		sheet.autoSizeColumn(columnCount);
		Cell cell = row.createCell(columnCount);
		if (valueOfCell instanceof Integer) {
			cell.setCellValue((Integer) valueOfCell);
		} else if (valueOfCell instanceof Long) {
			cell.setCellValue((Long) valueOfCell);
		} else if (valueOfCell instanceof String) {
			cell.setCellValue((String) valueOfCell);
		} 
		else if (valueOfCell instanceof Double)
			{
			cell.setCellValue((Double) valueOfCell);
			}
		else if (valueOfCell instanceof LocalDate)
		{
			cell.setCellValue((LocalDate) valueOfCell);
		}
		else {
			cell.setCellValue((Boolean) valueOfCell);
		}
		
		cell.setCellStyle(style);
	}

	private void write() {
		int rowCount = 1;
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);
		style.setFont(font);
		for (Cards record : cardDetailsList) {
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			createCell(row, columnCount++, record.getCardno(), style);
			createCell(row, columnCount++, record.getCardholdername(), style);
			createCell(row, columnCount++, record.getCardbalance(), style);
			createCell(row, columnCount++, record.getCardissueddate(), style);
			createCell(row, columnCount++, record.getCardexpirydate(), style);
			createCell(row, columnCount++, record.getCardstatus(), style);
			createCell(row, columnCount++, record.getBankid(), style);

		}
	}

	public void generateExcelFile(HttpServletResponse response) throws IOException {
		writeHeader();
		write();
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();
	}

}

package com.cmse.eventbasedreporting.model;

public enum StatusEnum {
	HOT,ACTIVE,ACTIVATION,BLOCK

}

package com.cmse.eventbasedreporting.model;
import lombok.AllArgsConstructor;


import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="cards")
@AllArgsConstructor
public class Cards {
	
	public Cards() {
		
	}
	
	@Id
	private long cardno;
	
	@Column(name = "cardholdername")
	private String cardholdername;
	
	@Column(name = "cardbalance")
	private double cardbalance;
	

	@Column(name = "cardissueddate",columnDefinition = "DATE")
	private LocalDate cardissueddate;
	
	@Column(name = "cardexpirydate",columnDefinition = "DATE")
	private LocalDate cardexpirydate;
	
	@Column(name = "cardstatus")
	private String cardstatus;
	
	
	@Column(name = "bankid")
	public long bankid;
	
	
	public Cards(String cardholdername, double cardbalance, LocalDate cardissueddate, LocalDate cardexpirydate,
			String cardstatus, long bankid) {
		super();
		this.cardholdername = cardholdername;
		this.cardbalance = cardbalance;
		this.cardissueddate = cardissueddate;
		this.cardexpirydate = cardexpirydate;
		this.cardstatus = cardstatus;
		this.bankid = bankid;
	}


	public long getCardno() {
		return cardno;
	}


	public void setCardno(long cardno) {
		this.cardno = cardno;
	}


	public String getCardholdername() {
		return cardholdername;
	}


	public void setCardholdername(String cardholdername) {
		this.cardholdername = cardholdername;
	}


	public double getCardbalance() {
		return cardbalance;
	}


	public void setCardbalance(double cardbalance) {
		this.cardbalance = cardbalance;
	}


	public LocalDate getCardissueddate() {
		return cardissueddate;
	}


	public void setCardissueddate(LocalDate cardissueddate) {
		this.cardissueddate = cardissueddate;
	}


	public LocalDate getCardexpirydate() {
		return cardexpirydate;
	}


	public void setCardexpirydate(LocalDate cardexpirydate) {
		this.cardexpirydate = cardexpirydate;
	}


	public String getCardstatus() {
		return cardstatus;
	}


	public void setCardstatus(String cardstatus) {
		this.cardstatus = cardstatus;
	}


	public long getBankid() {
		return bankid;
	}


	public void setBankid(long bankid) {
		this.bankid = bankid;
	}


	
}

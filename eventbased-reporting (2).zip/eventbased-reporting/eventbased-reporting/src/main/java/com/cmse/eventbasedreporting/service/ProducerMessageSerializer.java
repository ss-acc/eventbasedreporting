package com.cmse.eventbasedreporting.service;

import org.springframework.kafka.support.serializer.JsonSerializer;

import com.cmse.eventbasedreporting.model.Cards;

public class ProducerMessageSerializer extends JsonSerializer<Cards> {
}
